with open('./1912.featnames', 'r') as file:
    Lines = file.readlines()
    temp=[]
    for line in Lines:
        arr=line.strip().split()
        temp.append(arr[0]+" "+arr[1])

import csv

with open('names.csv', "w") as f:
    writer = csv.writer(f)
    writer.writerow(temp)
