from csv import writer
import csv
lists=[]
with open("./fb/1912.feat", 'r') as file:
    Lines = file.readlines()
    for line in Lines:
        arr=line.strip().split()
        arr = map(int, arr)
        lists.append(arr)

with open("./1912.csv", "a") as fp:
    wr = csv.writer(fp, dialect='excel')
    for list in lists:
        wr.writerow(list)
